package com.worldpay.fsEodConsol

import java.io.{File, FileInputStream}
import java.util.Properties

import org.apache.spark.sql._
import org.slf4j.Logger

import scala.collection.parallel.ForkJoinTaskSupport

object Utils extends SparkSessionWrapper {

  /** The readProperties method.
    *  This reads all the properties file and stores so that they can be retrieved with `props`.
    *  @param args the arguments passed to the main method
    */

   def readProperties(args: Array[String],logger: Logger) = {
     logger.info("readProperties method started")
    val props: Properties = new Properties()
    val jobPropPath = new File(args(0))
    val jobProp = new FileInputStream(jobPropPath)
    props.load(jobProp)
    props
  }

  /** The getParArray method.
    *  This converts Array to ParArray(parallel collection) and
    *  sets the parallel collection to use a fork-join pool with parallelism level as give in num_thread properties.
    *  @param path contains Array of extract_dates
    *  @param props
    */

  def getParArray(list: Array[Row] , props:Properties) = {
    val num_thread=s"${props.getProperty("num_thread")}"
    val extract_dates = list.par
    extract_dates.tasksupport = new ForkJoinTaskSupport(new scala.concurrent.forkjoin.ForkJoinPool(num_thread.toInt))
    extract_dates
  }

  /** The loadDaily method.
    *  @param path contains Array of extract_dates
    *  @param props
    */
  def loadDaily(source_name: String,target_path:String) ={
    val source= spark.sql("select * from audit." +source_name)
    source.write.parquet(target_path)
  }

  /** The loadMonthly method.
    *  @param path contains Array of extract_dates
    *  @param props
    */
  def loadMonthly(source_name: String,target_path:String) ={
    val source= spark.sql("select * from audit." +source_name)
    source.write.parquet(target_path)
  }

  /** The loadWhole method.
    *  @param source_name contains Array of extract_dates
    *  @param target_path
    */
  def loadWhole(source_name: String,target_path:String) ={
    val source= spark.sql("select * from audit." +source_name)
    source.write.parquet(target_path)
  }

  /** The loadCustom method.
    *  @param source_name contains Array of extract_dates
    *  @param target_path
    */
  def loadCustom(source_name: String,target_path:String) ={
    val source= spark.sql("select * from audit." +source_name)
    source.write.parquet(target_path)
  }
}
