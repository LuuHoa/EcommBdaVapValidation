package com.worldpay.fsEodConsol

import java.util.Properties

import org.slf4j.LoggerFactory

object TextToParqutMain extends SparkSessionWrapper with App {

  private val logger = LoggerFactory.getLogger(getClass.getName)
  logger.info("readProperties method started")

  val props: Properties = Utils.readProperties(args, logger)
  val source_fil_list_Path = s"${props.getProperty("source_fil_list_Path")}"

  val tables_array_list = spark.read.csv(source_fil_list_Path).collect()
  val tables_par_array_list = Utils.getParArray(tables_array_list, props)
  tables_par_array_list.foreach {
    source_table =>
      val source_name=source_table(0)
      val target_path=s"${props.getProperty("target_base_path")}"+"/"+source_name
      val load_type=source_table(1)
      load_type match{
        case dl => Utils.loadDaily(source_name.toString,target_path)
        case mn => Utils.loadMonthly(source_name.toString,target_path)
        case wt => Utils.loadWhole(source_name.toString,target_path)
        case ct => Utils.loadCustom(source_name.toString,target_path)
      }
  }
}

