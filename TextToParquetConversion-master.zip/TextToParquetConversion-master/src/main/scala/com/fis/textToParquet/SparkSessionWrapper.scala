package com.worldpay.fsEodConsol

import org.apache.spark.sql.SparkSession

/** The SparkSessionWrapper trait.
  * Classes/objects extending this trait will have sparkSession created and serializable across platforms(Scala).
  */
trait SparkSessionWrapper extends Serializable {

  lazy val spark: SparkSession = {
    SparkSession
      .builder()
      .enableHiveSupport()
      .getOrCreate()
  }

}
