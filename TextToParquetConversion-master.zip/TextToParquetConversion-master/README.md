# TextToParquetConversion
## Spark module to convert text formated tables history data to parquet file format.


#### Design
* [Click here for full design](https://fisglobal-my.sharepoint.com/:u:/r/personal/chandra_lekkala_fisglobal_com/_layouts/15/Doc.aspx?sourcedoc=%7B2F73F134-1A58-4455-82B1-A1D47ED138BF%7D&file=Ecomm%20History%20conversion%20Design.vsdx&action=default)

Below is high level Flow diagram

![Capture](https://github.worldpay.com/storage/user/51/files/4e54f880-a782-11ea-91f9-8eb12c030f75)

# TextToParquetConversion

TextToParquetConversion is a Spark Scala module which used to convert text file formated tables to parquet.

## Using TextToParquetConversion

To use TextToParquetConversion, follow these steps:

```
<usage_example>
```

Add run commands and examples you think users will find useful. Provide an options reference for bonus points!

## Contributing to TextToParquetConversion
<!--- If your README is long or you have some specific process or steps you want contributors to follow, consider creating a separate CONTRIBUTING.md file--->
To contribute to TextToParquetConversion, follow these steps:

[Git Cheat Sheet](https://github.github.com/training-kit/downloads/github-git-cheat-sheet.pdf)

1. Fork this repository.
2. Clone git repository to local: `git clone https://github.worldpay.com/<user>/eComm_Ingestion_ETL.git`
3. Checkout 'development' branch: `git checkout developemt`.
4. Make your changes in IDE(Intellij or SBT), test and commit them: `git commit -m '<commit_message>'`
5. Push to the original branch: `git push origin TextToParquetConversion/tree/development`
6. Create the pull request to merge with Master Repo.

Alternatively see the GitHub documentation on [creating a pull request](https://help.github.com/en/github/collaborating-with-issues-and-pull-requests/creating-a-pull-request).

## Deployment

Add additional notes about how to deploy this on a live system

## Built With

* [Intellij]() - IDE
* [Apache Spark 2.4.0]() - Unified Analytics Engine
* [Scala 2.11.0]() - Programming Language
* [Apache Log4j]() - Logging Framework
* [Maven](https://maven.apache.org/) - Dependency Management
* [Scala SBT](https://www.scala-sbt.org/) - Scala Build Tool

## Running the tests

Explain how to run the automated tests for this system

### Break down into end to end tests

Explain what these tests test and why

```
Give an example
```


## Contributors

Thanks to the following people who have contributed to this project:

* [@ChandraLekkala](https://github.worldpay.com/Chandra-Lekkala) 💻
* [@Sushanth](https://github.worldpay.com/Sushanth-Chindam) 💻
* [@PawanSingh](https://github.worldpay.com/Pawandeep-Singh) 👀


## Contact

If you want to contact me you can reach me at chandra.lekkala@fisglobal.com.

